-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 20, 2020 at 06:03 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bes`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendent`
--

CREATE TABLE `attendent` (
  `attendent_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `enroll`
--

CREATE TABLE `enroll` (
  `std_id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL,
  `cnic` varchar(11) NOT NULL,
  `address` varchar(130) NOT NULL,
  `email` varchar(100) NOT NULL,
  `guardian` varchar(80) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `pic_name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `enroll`
--

INSERT INTO `enroll` (`std_id`, `name`, `cnic`, `address`, `email`, `guardian`, `password`, `pic_name`) VALUES
(79, 'hzhh', 'hhsgs', 'jzhhz', 'jhzhgz', 'jzhhz', '6778', 'IMG_20200520_081927.jpg'),
(80, 'hurmat', '578', 'hagga', 'hurmat@yhaoo.com', 'shahid irfan', 'bvc', 'IMG_20200520_082124.jpg'),
(81, 'hurmat fatima', '1234567', 'home', 'hurmat@yahoo.com', 'shahid irfan', '155163', 'IMG_20200520_082439.jpg'),
(82, 'noor zahra', '6777', 'sargodha', 'noor@zahra.com', 'shahid irfan', 'noor', 'IMG_20200520_082748.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `entry`
--

CREATE TABLE `entry` (
  `entry_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `checkin_date` varchar(50) NOT NULL,
  `checkin_time` varchar(50) NOT NULL,
  `checkin_pic` varchar(50) NOT NULL,
  `checkin_location` varchar(50) NOT NULL,
  `checkout_date` varchar(50) NOT NULL,
  `checkout_time` varchar(50) NOT NULL,
  `checkout_pic` varchar(50) NOT NULL,
  `checkout_location` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `home_entry`
--

CREATE TABLE `home_entry` (
  `home_id` int(11) NOT NULL,
  `visit` varchar(50) NOT NULL,
  `departure_date` varchar(50) NOT NULL,
  `departure_time` varchar(50) NOT NULL,
  `departure_pic` varchar(50) NOT NULL,
  `departure_location` varchar(50) NOT NULL,
  `arrival_date` varchar(50) NOT NULL,
  `arrival_time` varchar(50) NOT NULL,
  `arrival_location` varchar(50) NOT NULL,
  `arrival_pic` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE `photos` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `path` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `name`, `path`) VALUES
(1, 'testt.jpg', 'images/testt.jpg'),
(2, 'testt.jpg', 'images/testt.jpg'),
(3, 'testt.jpg', 'images/testt.jpg'),
(4, 'IMG_20200510_052333.jpg', 'images/IMG_20200510_052333.jpg'),
(6, 'IMG_20200510_081717.jpg', 'images/IMG_20200510_081717.jpg'),
(7, 'IMG_20200511_063404.jpg', 'images/IMG_20200511_063404.jpg'),
(8, 'IMG_20200511_063620.jpg', 'images/IMG_20200511_063620.jpg'),
(9, 'IMG_20200511_074336.jpg', 'images/IMG_20200511_074336.jpg'),
(10, 'IMG_20200511_074655.jpg', 'images/IMG_20200511_074655.jpg'),
(11, 'IMG_20200511_080110.jpg', 'images/IMG_20200511_080110.jpg'),
(12, 'IMG_20200511_080201.jpg', 'images/IMG_20200511_080201.jpg'),
(13, 'IMG_20200511_080305.jpg', 'images/IMG_20200511_080305.jpg'),
(14, 'IMG_20200513_082016.jpg', 'images/IMG_20200513_082016.jpg'),
(15, 'IMG_20200513_082834.jpg', 'http://192.168.43.161/images/I'),
(16, 'IMG_20200513_083136.jpg', 'http://192.168.43.161/images/I'),
(17, 'IMG_20200513_083341.jpg', 'http://192.168.43.161/images/I'),
(18, 'IMG_20200513_083532.jpg', 'images/IMG_20200513_083532.jpg'),
(19, 'IMG_20200513_085243.jpg', 'http://192.168.43.161/images/I'),
(20, 'IMG_20200513_085409.jpg', 'http://192.168.43.161/images/I'),
(21, 'IMG_20200513_085659.jpg', 'images/IMG_20200513_085659.jpg'),
(22, 'IMG_20200520_081927.jpg', 'images/IMG_20200520_081927.jpg'),
(23, 'IMG_20200520_082124.jpg', 'images/IMG_20200520_082124.jpg'),
(24, 'IMG_20200520_082439.jpg', 'images/IMG_20200520_082439.jpg'),
(25, 'IMG_20200520_082748.jpg', 'images/IMG_20200520_082748.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendent`
--
ALTER TABLE `attendent`
  ADD PRIMARY KEY (`attendent_id`);

--
-- Indexes for table `enroll`
--
ALTER TABLE `enroll`
  ADD PRIMARY KEY (`std_id`);

--
-- Indexes for table `entry`
--
ALTER TABLE `entry`
  ADD PRIMARY KEY (`entry_id`),
  ADD KEY `std_id` (`std_id`);

--
-- Indexes for table `home_entry`
--
ALTER TABLE `home_entry`
  ADD PRIMARY KEY (`home_id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendent`
--
ALTER TABLE `attendent`
  MODIFY `attendent_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `enroll`
--
ALTER TABLE `enroll`
  MODIFY `std_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `entry`
--
ALTER TABLE `entry`
  MODIFY `entry_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `home_entry`
--
ALTER TABLE `home_entry`
  MODIFY `home_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `entry`
--
ALTER TABLE `entry`
  ADD CONSTRAINT `entry_ibfk_1` FOREIGN KEY (`std_id`) REFERENCES `enroll` (`std_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
